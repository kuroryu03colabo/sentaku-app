# Laundry_caremark_250706 > 2025-07-13 12:33pm
https://universe.roboflow.com/rkuroda/laundry_caremark_250706

Provided by a Roboflow user
License: CC BY 4.0

