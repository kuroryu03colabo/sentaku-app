# Laundry_caremark_250706 > 2025-07-12 3:44pm
https://universe.roboflow.com/rkuroda/laundry_caremark_250706

Provided by a Roboflow user
License: CC BY 4.0

